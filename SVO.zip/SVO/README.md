# Unciv-mod-example

Это мод который отображает войну в украине. В моде: 7 цивилизаций(3 это города государства), несколько юнитов и два здания. и другое

https://github.com/ArseniySCM/SVO-mod/tree/unciv-mod